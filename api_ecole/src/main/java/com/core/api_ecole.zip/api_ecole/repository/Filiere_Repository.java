package com.core.api_ecole.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.core.api_ecole.model.Filiere;


@Repository
public interface Filiere_Repository extends CrudRepository<Filiere, Long>{

}
