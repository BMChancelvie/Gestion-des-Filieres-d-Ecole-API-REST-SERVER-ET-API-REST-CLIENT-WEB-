package com.core.api_ecole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEcoleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEcoleApplication.class, args);
	}

}
