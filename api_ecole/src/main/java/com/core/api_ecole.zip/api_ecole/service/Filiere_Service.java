package com.core.api_ecole.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.core.api_ecole.model.Filiere;
import com.core.api_ecole.repository.Filiere_Repository;

import lombok.Data;

@Data
@Service
public class Filiere_Service {

	@Autowired
	private Filiere_Repository filiereRepository;
	
	public Optional<Filiere> getFiliere(final Long id_filiere) {
		return filiereRepository.findById(id_filiere);
	}
	
	public Iterable<Filiere> getFiliere() {
		return filiereRepository.findAll();
	}
	
	public void deleteFiliere(final Long id_filiere) {
		filiereRepository.deleteById(id_filiere);
	}
	
	public Filiere saveFiliere(Filiere filiere) {
		Filiere savedFiliere = filiereRepository.save(filiere);
		return savedFiliere;
	}

}
